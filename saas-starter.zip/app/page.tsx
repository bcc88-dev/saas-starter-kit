import Link from 'next/link'

export default function Home() {
  const tiers = [
    {
      name: 'Free',
      price: '$0',
      features: ['100 API calls/month', '1 repository', 'Community support'],
      cta: 'Get Started',
      href: '/login',
    },
    {
      name: 'Pro',
      price: '$29',
      features: ['10,000 API calls/month', '10 repositories', 'Email support', 'Rate limit: 100 req/min'],
      cta: 'Subscribe',
      href: '/api/create-checkout?tier=PRO',
      featured: true,
    },
    {
      name: 'Enterprise',
      price: '$99',
      features: ['100,000 API calls/month', 'Unlimited repos', 'Priority support', 'Custom integrations'],
      cta: 'Contact Us',
      href: '/api/create-checkout?tier=ENTERPRISE',
    },
  ]

  return (
    <div>
      {/* Hero */}
      <section className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-5xl font-bold mb-6">
          Build your SaaS in minutes
        </h1>
        <p className="text-xl text-slate-600 dark:text-slate-300 max-w-2xl mx-auto mb-8">
          Authentication, subscriptions, billing, and rate limiting — all pre-built.
          Deploy to Vercel in one click.
        </p>
        <Link
          href="/login"
          className="inline-block bg-primary-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-primary-700"
        >
          Start Building
        </Link>
      </section>

      {/* Pricing */}
      <section className="max-w-7xl mx-auto px-4 py-20">
        <h2 className="text-3xl font-bold text-center mb-12">Simple Pricing</h2>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {tiers.map((tier) => (
            <div
              key={tier.name}
              className={`rounded-xl border p-8 ${
                tier.featured
                  ? 'border-primary-500 ring-2 ring-primary-500 bg-slate-50 dark:bg-slate-800'
                  : 'border-slate-200 dark:border-slate-700'
              }`}
            >
              <h3 className="text-2xl font-bold mb-2">{tier.name}</h3>
              <p className="text-4xl font-bold mb-6">{tier.price}<span className="text-lg text-slate-500">/mo</span></p>
              <ul className="space-y-3 mb-8">
                {tier.features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <span className="text-green-500">✓</span> {f}
                  </li>
                ))}
              </ul>
              <Link
                href={tier.href}
                className={`block text-center py-2 rounded-lg font-medium ${
                  tier.featured
                    ? 'bg-primary-600 text-white hover:bg-primary-700'
                    : 'bg-slate-100 dark:bg-slate-700 hover:bg-slate-200'
                }`}
              >
                {tier.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}